#ifndef STRING_UTILS_H
#define STRING_UTILS_H

void reverseString(char str[]);
void toUpperCase(char str[]);

#endif 